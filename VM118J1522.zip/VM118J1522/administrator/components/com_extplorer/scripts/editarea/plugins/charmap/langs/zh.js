editArea.add_lang("zh",{
charmap_but: "软键盘",
charmap_title: "软键盘",
charmap_choose_block: "选择一个语言块",
charmap_insert:"插入此字符"
});
